package J07007;
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
	}

}
